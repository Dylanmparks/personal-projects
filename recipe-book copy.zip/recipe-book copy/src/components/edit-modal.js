import React, { Component } from 'react';
import { Modal, Button, Form, FormGroup, Col, ControlLabel, FormControl } from 'react-bootstrap';

class EditModal extends Component {
  constructor(props) {
    super(props)

    this.state = {
      titleValidationState: null,
      ingredientValidationState: null,
      title: "",
      ingredients: "",
      editIndex: ""
    }
  }

  // componentWillReceiveProps(nextProps) {
  //   this.setState({
  //     title: this.props.editTitle,
  //     ingredients: this.props.editIngredients,
  //     editIndex: this.props.editIndex
  //   }, () => console.log(this.state.editIndex, this.state.title))
  // }

  handleInputChange = (event) => {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    });
  }


  handleSubmit = () => {

    let validTitle, validIngredients = true

    //Check For Title
    if(this.state.title.length < 1) {
      validTitle = false
      this.setState({
        titleValidationState: "error"
      })
      console.log("Enter Title")
    } else {
      validTitle = true
    }

    //Check for Duplicate Names
    if(this.state.title.length > 1) {
      this.props.recipes.map((recipe) => {
        if(recipe.title === this.state.title) {
          validTitle = false
          this.setState({
            titleValidationState: "error"
          })
          console.log("Duplicate Title")
        }
      })
    }

    if(validTitle) {
      this.setState({
        titleValidationState: "success"
      })
    }

    //Check for Ingredients
    if(this.state.ingredients.length < 1) {
      //Validate Error
      validIngredients = false
      this.setState({
        ingredientValidationState: "error"
      })
      console.log("Enter Ingredients")
    } else if(validIngredients) {
      this.setState({
        ingredientValidationState: "success"
      })
    }

    //Submit if All Valid
    if(validTitle && validIngredients) {
      this.props.handleEditSave(this.state.title, this.state.ingredients, this.props.editIndex)
      console.log("updated")

      this.setState({
        title: "",
        ingredients: "",
        titleValidationState: null,
        ingredientValidationState: null
      })
    }
  }

  render() {
    return (
      <Modal show={this.props.show}>
        <Modal.Header>
          <Modal.Title>Edit {this.props.editTitle} Recipe</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form horizontal>
            <FormGroup
              controlId="formAddTitle"
              validationState={this.state.titleValidationState}
              >
              <Col componentClass={ControlLabel} sm={2}>
                Title
              </Col>
              <Col sm={10}>
                <FormControl
                  name="title"
                  type="text"
                  placeholder={this.props.editTitle}
                  value={this.state.editTitle}
                  onChange={this.handleInputChange}
                />
              </Col>
            </FormGroup>
            <FormGroup
              controlId="formAddIngredients"
              validationState={this.state.ingredientValidationState}
              >
              <Col componentClass={ControlLabel} sm={2}>
                Ingredients
              </Col>
              <Col sm={10}>
                <FormControl
                  name="ingredients"
                  componentClass="textarea"
                  type="textarea"
                  placeholder={this.props.editIngredients}
                  value={this.state.editIngredients}
                  onChange={this.handleInputChange}
                />
              </Col>
            </FormGroup>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={this.handleSubmit} bsStyle="success">Save Changes</Button>
          <Button onClick={this.props.onHide}>Leave Unchanged</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}

export default EditModal;
