import React, { Component } from 'react';
import { Button, ButtonGroup, Panel, ListGroup, ListGroupItem } from 'react-bootstrap';

class RecipeItem extends Component {

  listGroupItem = this.props.ingredients.map((ingredient, i) => {
    return (
      <ListGroupItem
        key={i}>
        {ingredient}
      </ListGroupItem>
    )
  })

  render() {
    return(
      <Panel bsStyle="primary" header={this.props.title} eventKey={this.props.key}>
        <ListGroup>
          {this.listGroupItem}
        </ListGroup>
        <ButtonGroup>
          <Button onClick={this.props.handleEdit} bsStyle="warning" bsSize="small">Edit</Button>
          <Button onClick={this.props.handleDelete} bsStyle="danger" bsSize="small">Delete</Button>
        </ButtonGroup>
      </Panel>
    )
  }
}

export default RecipeItem;
