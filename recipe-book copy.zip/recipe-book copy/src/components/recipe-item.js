import React, { Component } from 'react';
import { Button, ButtonGroup, Panel, ListGroup, ListGroupItem } from 'react-bootstrap';
import '../App.css';

class RecipeItem extends Component {

  handleEditClick = () => {
    let index = undefined
    this.props.recipes.map((recipe,i) => {
      if(recipe.title === this.props.title) {
        index = i
      }
    })

    this.props.handleEditModal(this.props.title, this.props.ingredients, index)

  }

  handleDelete = () => {
    this.props.recipes.map((recipe, i) => {
      if(recipe.title === this.props.title) {
        this.props.deleteRecipe(i)
      }
    })
  }


  render() {
    return(
      <Panel bsStyle="info" header={this.props.title} eventKey={this.props.key}>
        <ListGroup>
          {this.props.ingredients.map((ingredient, i) => {
            return (
              <ListGroupItem
                key={i}>
                {ingredient}
              </ListGroupItem>
            )
          })}
        </ListGroup>
        <ButtonGroup id="recipe-btns">
          <Button onClick={this.handleEditClick} bsStyle="warning" bsSize="small">Edit</Button>
          <Button onClick={this.handleDelete} bsStyle="danger" bsSize="small">Delete</Button>
        </ButtonGroup>
      </Panel>
    )
  }
}

export default RecipeItem;
