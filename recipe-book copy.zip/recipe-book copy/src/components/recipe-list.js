import React, { Component } from 'react';
import { Accordion } from 'react-bootstrap';
import RecipeItem from './recipe'

class RecipeList extends Component {
  constructor(props) {
    super(props)

    this.state = {

    }
  };

  recipeList =  this.props.recipes.map((recipes, i) => {
    return (
      <RecipeItem
        title={recipes.title}
        ingredients={recipes.ingredients}
        handleEdit={this.props.handleEdit}
        handleDelete={this.props.handleDelete}
        key={i}
      />
    )
  })

  render() {
    return (
      <Accordion>
        {this.recipeList}
      </Accordion>
    )
  }
}

export default RecipeList;
