import _ from 'lodash';
import React, { Component } from 'react';
import { Accordion, Panel } from 'react-bootstrap';
import RecipeItem from './recipe-item';

class RecipeList extends Component {


  render() {
    return (
      <Accordion>
        {this.props.recipes.map((recipe, index) => {
          return <RecipeItem
                    recipes={this.props.recipes}
                    title={recipe.title}
                    ingredients={recipe.ingredients}
                    handleEditModal={this.props.handleEditModal}
                    deleteRecipe={this.props.deleteRecipe}
                    key={index}
                  />
        })}
      </Accordion>
    )
  }
}

export default RecipeList;
