import React, { Component } from 'react';
import {Button} from 'react-bootstrap';
import RecipeList from './recipe-list';


class RecipeBook extends Component {

  constructor(props) {
    super(props)

    this.state = { }
  }

  recipes = [
    {title: "Spaghetti", ingredients: ["Noodles","Meatballs","Pasta"]},
    {title: "Meatloaf", ingredients: ["Loaf","Meat"]},
    {title: "Veggie Burger", ingredients: ["Beans","Tempe","Buns","Ketchup"]}
  ]

  handleAdd = () => {
    console.log("add pressed")
    const newRecipe = [{title: "Tofu Scramble", ingredients: ["Tofu", "Eggs"]}]
    this.recipes = this.recipes.concat(newRecipe);

    console.log(this.recipes)
    
  }

  handleEdit = () => {
    console.log("edit pressed for: ")
  }

  handleDelete = () => {
    console.log("delete pressed for: ")
  }

  render() {
    return (
      <div>
          <Button onClick={this.handleAdd} bsStyle="primary">Add</Button>
          <RecipeList handleEdit={this.handleEdit} handleDelete={this.handleDelete} recipes={this.recipes}/>
      </div>
    )
  }
}

export default RecipeBook;
