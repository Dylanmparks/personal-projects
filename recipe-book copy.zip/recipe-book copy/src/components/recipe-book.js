import React, { Component } from 'react';
import {Button, Modal} from 'react-bootstrap';
import RecipeList from './recipe-list';
import AddModal from './add-modal';
import EditModal from './edit-modal';
import '../App.css';


class RecipeBook extends Component {

  constructor(props) {
    super(props)

    this.state = {
      recipes : [
       {title: "Spaghetti", ingredients: ["Noodles","Meatballs","Pasta"]},
       {title: "Meatloaf", ingredients: ["Loaf","Meat"]},
       {title: "Veggie Burger", ingredients: ["Beans","Tempe","Buns","Ketchup"]}
     ],
     showAddModal: false,
     showEditModal: false,
     editTitle: '',
     editIngredients: '',
     editIndex: undefined
    }
  }


  //Handle Open/Close of Modals
  openAddModal = () => {
    this.setState({showAddModal: true})
  }
  closeAddModal = () => {
    this.setState({showAddModal: false})
  }
  openEditModal = () => {
    this.setState({showEditModal: true})
  }
  closeEditModal = () => {
    this.setState({showEditModal: false})
  }

  //Add New Recipe Button
  handleAdd = (title, ingredientString) => {
    let ingredientList = ingredientString.split(",")
    let newRecipe = {title: title, ingredients: ingredientList}
    let recipes = this.state.recipes.slice()
    recipes.push(newRecipe)
    this.setState({ recipes: recipes})
  }

  //Edit Recipe Button
  handleEditModal = (title, ingredients, index) => {

    let ingredientString = ingredients.join()
    this.setState(
      {
        editTitle: title,
        editIngredients: ingredients,
        editIndex: index
      },
     this.openEditModal()
    )

  }

  handleEditSave = (title, ingredientString, index) => {
    let ingredientList = ingredientString.split(",")
    console.log(ingredientList)
    let newRecipe = {title: title, ingredients: ingredientList}
    let recipes = this.state.recipes.slice()
    recipes.splice(index, 1, newRecipe)
    console.log(recipes)
    this.setState({ recipes: recipes })
    this.closeEditModal()
  }

  //Delete Recipe Button
  deleteRecipe = (i) => {
    let recipes = this.state.recipes
    recipes.splice(i, 1)
    this.setState({ recipes: recipes })
  }

  render() {
    return (
      <div>
          <Button id="add-btn" onClick={this.openAddModal} bsStyle="primary">New Recipe</Button>
          <RecipeList
            handleEditModal={this.handleEditModal}
            deleteRecipe={this.deleteRecipe}
            recipes={this.state.recipes}
          />
          <AddModal
            recipes={this.state.recipes}
            handleAdd={this.handleAdd}
            show={this.state.showAddModal}
            onHide={this.closeAddModal}
          />
          <EditModal
            recipes={this.state.recipes}
            handleEditSave={this.handleEditSave}
            editTitle={this.state.editTitle}
            editIngredients={this.state.editIngredients}
            editIndex={this.state.editIndex}
            show={this.state.showEditModal}
            onHide={this.closeEditModal}
          />
      </div>
    )
  }
}

export default RecipeBook;
