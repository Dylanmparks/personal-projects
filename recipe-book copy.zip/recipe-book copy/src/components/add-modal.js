import React, { Component } from 'react';
import { Modal, Button, Form, FormGroup, Col, ControlLabel, FormControl } from 'react-bootstrap';

class AddModal extends Component {
  constructor(props) {
    super(props)

    this.state = {
      titleValidationState: null,
      ingredientValidationState: null,
      title: "",
      ingredients: ""
    }
  }

  handleInputChange = (event) => {
    const target = event.target
    const value = target.value
    const name = target.name

    this.setState({
      [name]: value
    });
  }



  handleSubmit = () => {
    let validTitle, validIngredients = true

    //Check For Title
    if(this.state.title.length < 1) {
      validTitle = false
      this.setState({
        titleValidationState: "error"
      })
      console.log("Enter Title")
    } else {
      validTitle = true
    }

    //Check for Duplicate Names
    if(this.state.title.length > 1) {
      this.props.recipes.map((recipe) => {
        if(recipe.title === this.state.title) {
          validTitle = false
          this.setState({
            titleValidationState: "error"
          })
          console.log("Duplicate Title")
        }
      })
    }

    if(validTitle) {
      this.setState({
        titleValidationState: "success"
      })
    }

    //Check for Ingredients
    if(this.state.ingredients.length < 1) {
      //Validate Error
      validIngredients = false
      this.setState({
        ingredientValidationState: "error"
      })
      console.log("Enter Ingredients")
    } else if(validIngredients) {
      this.setState({
        ingredientValidationState: "success"
      })
    }

    //Submit if All Valid
    if(validTitle && validIngredients) {
      console.log("title: ", this.state.title)
      console.log("ingredients: ", this.state.ingredients)
      this.props.handleAdd(this.state.title, this.state.ingredients)

      this.setState({
        title: "",
        ingredients: "",
        titleValidationState: null,
        ingredientValidationState: null
      })
      this.props.onHide()
    }
  }


  render() {
    return (
      <Modal show={this.props.show}>
        <Modal.Header>
          {this.validateAlert}
          <Modal.Title>Add a New Recipe</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form horizontal>
            <FormGroup
              controlId="formAddTitle"
              validationState={this.state.titleValidationState}
              >
              <Col componentClass={ControlLabel} sm={2}>
                Title
              </Col>
              <Col sm={10}>
                <FormControl
                  name="title"
                  type="text"
                  placeholder="Enter A Unique Recipe Title"
                  value={this.state.title}
                  onChange={this.handleInputChange}
                />
              </Col>
            </FormGroup>
            <FormGroup
              controlId="formAddIngredients"
              validationState={this.state.ingredientValidationState}
              >
              <Col componentClass={ControlLabel} sm={2}>
                Ingredients
              </Col>
              <Col sm={10}>
                <FormControl
                  name="ingredients"
                  componentClass="textarea"
                  type="textarea"
                  placeholder="Enter Ingredients Separated By Commas. Example: Noodles,Tomatoes,Basil"
                  value={this.state.ingredients}
                  onChange={this.handleInputChange}
                />
              </Col>
            </FormGroup>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={this.handleSubmit} bsStyle="success">Add</Button>
          <Button onClick={this.props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    )
  }
}

export default AddModal;
